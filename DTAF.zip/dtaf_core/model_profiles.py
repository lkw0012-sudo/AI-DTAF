"""Data-driven local model profile loading without model-specific code paths."""

from __future__ import annotations

import fnmatch
import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Mapping


DEFAULT_PROFILE: Dict[str, Any] = {
    "context_length": 16384,
    "temperature": 0.0,
    "top_p": 0.1,
    "repeat_penalty": 1.05,
    "json_mode": True,
    "stop_sequences": [],
    "maximum_output_tokens": 4096,
    "timeout_seconds": 600,
    "network_retries": 3,
    "validation_retries": 2,
}


def load_model_profiles(path: Path) -> Dict[str, Any]:
    if not Path(path).exists():
        return {"default": deepcopy(DEFAULT_PROFILE), "profiles": {}}
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Model profile configuration must be a JSON object")
    default = deepcopy(DEFAULT_PROFILE)
    default.update(data.get("default", {}))
    return {"default": default, "profiles": dict(data.get("profiles", {}))}


def resolve_model_profile(
    model: str, configuration: Mapping[str, Any]
) -> Dict[str, Any]:
    profile = deepcopy(dict(configuration.get("default", DEFAULT_PROFILE)))
    matches = []
    for pattern, overrides in dict(configuration.get("profiles", {})).items():
        if fnmatch.fnmatchcase(str(model).casefold(), str(pattern).casefold()):
            matches.append((len(str(pattern)), str(pattern), dict(overrides)))
    for _, pattern, overrides in sorted(matches):
        profile.update(overrides)
        profile["matched_profile"] = pattern
    profile["model"] = model
    return profile

