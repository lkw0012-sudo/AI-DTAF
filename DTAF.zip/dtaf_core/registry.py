"""Canonical Digital Twin Capability registry loaded from ``cpt.md``."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Tuple


_CAPABILITY_HEADING = re.compile(
    r"^####\s+([A-Z]{2}\.[A-Z0-9]{2})\s+(.+?)\s*$"
)
_CAPABILITY_ID = re.compile(r"^[A-Z]{2}\.[A-Z0-9]{2}$")


class CapabilityRegistryError(ValueError):
    """A capability identifier or name could not be resolved canonically."""


@dataclass(frozen=True)
class Capability:
    capability_id: str
    name: str
    category: str
    description: str = ""
    purpose: str = ""


@dataclass(frozen=True)
class CapabilityResolution:
    input_value: str
    capability_id: str
    normalized: bool
    normalization_reason: str = ""


class CapabilityRegistry:
    """Read-only capability registry derived from the checked-in CPT source."""

    def __init__(self, capabilities: Iterable[Capability]) -> None:
        records = list(capabilities)
        by_id: Dict[str, Capability] = {}
        for capability in records:
            if capability.capability_id in by_id:
                raise CapabilityRegistryError(
                    f"Duplicate CPT capability identifier: {capability.capability_id}"
                )
            by_id[capability.capability_id] = capability
        if not by_id:
            raise CapabilityRegistryError("CPT registry is empty")
        self._by_id = by_id
        self._by_name: Dict[str, List[str]] = {}
        for capability in records:
            key = self._normalize_name(capability.name)
            self._by_name.setdefault(key, []).append(capability.capability_id)

    @classmethod
    def load(cls, path: Path) -> "CapabilityRegistry":
        text = Path(path).read_text(encoding="utf-8")
        records: List[Capability] = []
        current: Optional[Dict[str, str]] = None
        section = ""
        for line in text.splitlines():
            heading = _CAPABILITY_HEADING.match(line)
            if heading:
                if current is not None:
                    records.append(Capability(**current))
                capability_id, name = heading.groups()
                current = {
                    "capability_id": capability_id,
                    "name": name.strip(),
                    "category": capability_id.split(".", 1)[0],
                    "description": "",
                    "purpose": "",
                }
                section = ""
                continue
            if current is None:
                continue
            if line.startswith("**Description:**"):
                current["description"] = line.split(":", 1)[1].strip()
                section = "description"
            elif line.startswith("**Purpose:**"):
                current["purpose"] = line.split(":", 1)[1].strip()
                section = "purpose"
            elif line.startswith("#### ") or line.startswith("### "):
                section = ""
            elif line.strip() and section and not line.startswith("**"):
                current[section] = (current[section] + " " + line.strip()).strip()
        if current is not None:
            records.append(Capability(**current))
        return cls(records)

    @staticmethod
    def _normalize_name(value: str) -> str:
        return re.sub(r"[^a-z0-9]+", " ", str(value).casefold()).strip()

    @property
    def ids(self) -> set[str]:
        return set(self._by_id)

    def __contains__(self, capability_id: object) -> bool:
        return str(capability_id or "").upper() in self._by_id

    def get(self, capability_id: str) -> Capability:
        normalized = str(capability_id or "").strip().upper()
        try:
            return self._by_id[normalized]
        except KeyError as exc:
            raise CapabilityRegistryError(
                f"Unknown CPT capability identifier: {capability_id}"
            ) from exc

    def resolve(self, value: str, *, allow_name: bool = True) -> CapabilityResolution:
        raw = str(value or "").strip()
        upper = raw.upper()
        if upper in self._by_id:
            return CapabilityResolution(
                input_value=raw,
                capability_id=upper,
                normalized=raw != upper,
                normalization_reason="case_normalized" if raw != upper else "",
            )
        if re.match(r"^[A-Z]{2}[-_]", upper) or re.match(r"^[A-Z]{2}\.\d", upper):
            raise CapabilityRegistryError(
                f"Malformed CPT capability identifier: {raw}"
            )
        if _CAPABILITY_ID.fullmatch(upper):
            raise CapabilityRegistryError(f"Unknown CPT capability identifier: {raw}")
        if not allow_name:
            raise CapabilityRegistryError(f"Malformed CPT capability identifier: {raw}")
        name_key = self._normalize_name(raw)
        matches = self._by_name.get(name_key, [])
        if not matches:
            raise CapabilityRegistryError(
                f"Unknown capability name or identifier: {raw}"
            )
        if len(matches) > 1:
            raise CapabilityRegistryError(
                f"Ambiguous capability name {raw!r}: {', '.join(matches)}"
            )
        return CapabilityResolution(
            input_value=raw,
            capability_id=matches[0],
            normalized=True,
            normalization_reason="unambiguous_name_to_id",
        )

    def to_list(self) -> List[Dict[str, str]]:
        return [asdict(self._by_id[key]) for key in self._by_id]

    def validate_hardcoded_catalog(
        self, catalog: Iterable[Tuple[int, int, str, str]]
    ) -> Dict[str, List[str]]:
        hard_ids = [str(row[2]) for row in catalog]
        return {
            "hardcoded_not_in_cpt": sorted(set(hard_ids) - self.ids),
            "cpt_not_in_hardcoded": sorted(self.ids - set(hard_ids)),
            "duplicate_hardcoded_ids": sorted(
                {capability_id for capability_id in hard_ids if hard_ids.count(capability_id) > 1}
            ),
        }

