"""Deterministic Markdown rendering for validated DTAF JSON objects."""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence


def _text(value: Any) -> str:
    return str(value or "").strip().replace("\r", " ").replace("\n", " ")


def _bullets(items: Iterable[Any], *, empty: str = "None recorded.") -> List[str]:
    rows = [f"- {_text(item)}" for item in items if _text(item)]
    return rows or [f"- {empty}"]


def _table(headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> List[str]:
    out = [
        "| " + " | ".join(headers) + " |",
        "|" + "|".join("---" for _ in headers) + "|",
    ]
    for row in rows:
        out.append("| " + " | ".join(_text(cell).replace("|", "\\|") for cell in row) + " |")
    return out


def render_step0(data: Mapping[str, Any]) -> str:
    lines = ["# Step 0: Use-Case Suitability", "", _text(data.get("suitability_summary")), ""]
    rows = []
    for area in data.get("business_areas", []):
        rows.append(
            [
                area.get("area_id"),
                area.get("name"),
                "; ".join(area.get("challenges", [])),
                "; ".join(area.get("root_causes", [])),
                "; ".join(area.get("business_impacts", [])),
                "; ".join(area.get("actionable_insights", [])),
            ]
        )
    lines.extend(
        _table(
            [
                "Area ID",
                "Business Area",
                "Challenges",
                "Root Causes",
                "Impact",
                "Actionable Insights",
            ],
            rows,
        )
    )
    lines.extend(["", "## Missing Information", ""])
    lines.extend(_bullets(data.get("missing_information", [])))
    return "\n".join(lines).strip() + "\n"


def render_step1(data: Mapping[str, Any]) -> str:
    lines = [
        "# Step 1: Validated Digital Twin Business Requirements",
        "",
        "## Business Context",
        "",
        _text(data.get("business_context")),
        "",
        "## Statement Ledger",
        "",
    ]
    lines.extend(
        _table(
            ["ID", "Statement", "Classification", "Time", "Confirmation", "Sources"],
            [
                [
                    row.get("statement_id"),
                    row.get("text"),
                    row.get("statement_type"),
                    row.get("temporal_status"),
                    "Required" if row.get("confirmation_required") else "No",
                    ", ".join(row.get("source_refs", [])),
                ]
                for row in data.get("statements", [])
            ],
        )
    )
    lines.extend(["", "## Requirements", ""])
    lines.extend(
        _table(
            ["Requirement ID", "Category", "Title", "Description", "Classification", "Time"],
            [
                [
                    row.get("requirement_id"),
                    row.get("category"),
                    row.get("title"),
                    row.get("description"),
                    row.get("statement_type"),
                    row.get("temporal_status"),
                ]
                for row in data.get("requirements", [])
            ],
        )
    )
    lines.extend(["", "## Objectives", ""])
    lines.extend(
        _table(
            ["Objective ID", "Description", "Requirements", "Classification", "Time"],
            [
                [
                    row.get("objective_id"),
                    row.get("description"),
                    ", ".join(row.get("related_requirement_ids", [])),
                    row.get("statement_type"),
                    row.get("temporal_status"),
                ]
                for row in data.get("objectives", [])
            ],
        )
    )
    lines.extend(["", "## KPIs", ""])
    lines.extend(
        _table(
            ["KPI ID", "Name", "Measurement", "Baseline", "Target", "Objectives"],
            [
                [
                    row.get("kpi_id"),
                    row.get("name"),
                    row.get("measurement"),
                    row.get("baseline"),
                    row.get("target"),
                    ", ".join(row.get("related_objective_ids", [])),
                ]
                for row in data.get("kpis", [])
            ],
        )
    )
    lines.extend(["", "## Decisions", ""])
    lines.extend(
        _table(
            ["Decision ID", "Description", "Requirements"],
            [
                [
                    row.get("decision_id"),
                    row.get("description"),
                    ", ".join(row.get("related_requirement_ids", [])),
                ]
                for row in data.get("decisions", [])
            ],
        )
    )
    lines.extend(["", "## Risks", ""])
    lines.extend(
        _table(
            ["Risk ID", "Description", "Mitigation", "Requirements"],
            [
                [
                    row.get("risk_id"),
                    row.get("description"),
                    row.get("mitigation"),
                    ", ".join(row.get("related_requirement_ids", [])),
                ]
                for row in data.get("risks", [])
            ],
        )
    )
    lines.extend(["", "## Missing Information", ""])
    lines.extend(_bullets(data.get("missing_information", [])))
    return "\n".join(lines).strip() + "\n"


def render_step2(data: Mapping[str, Any]) -> str:
    lines = ["# Step 2: Validated Capability Selection", ""]
    lines.extend(
        _table(
            [
                "Capability ID",
                "Name",
                "Priority",
                "Priority Source",
                "Requirements",
                "Justification",
                "Deployment",
            ],
            [
                [
                    row.get("capability_id"),
                    row.get("name"),
                    row.get("priority"),
                    row.get("priority_source"),
                    ", ".join(row.get("related_requirement_ids", [])),
                    row.get("justification"),
                    row.get("deployment_considerations"),
                ]
                for row in data.get("capabilities", [])
            ],
        )
    )
    for title, key in (
        ("Capability Gaps", "capability_gaps"),
        ("Implementation Phases", "implementation_phases"),
        ("Specialized Expertise", "specialized_expertise"),
    ):
        lines.extend(["", f"## {title}", ""])
        lines.extend(_bullets(data.get(key, [])))
    return "\n".join(lines).strip() + "\n"


def render_step3(data: Mapping[str, Any]) -> str:
    lines = ["# Step 3: Validated Capability Deep Dives", ""]
    for row in data.get("deep_dives", []):
        lines.extend(
            [
                f"## {_text(row.get('capability_id'))} — {_text(row.get('name'))}",
                "",
                f"- **Selection basis:** {_text(row.get('selection_basis'))}",
                f"- **Related requirements:** {', '.join(row.get('related_requirement_ids', []))}",
                "",
                "### Specific Requirements",
                "",
                *_bullets(row.get("specific_requirements", [])),
                "",
                "### Success Criteria",
                "",
                *_bullets(row.get("success_criteria", [])),
                "",
                "### Recommended Technology Approaches",
                "",
                *_bullets(row.get("technology_approaches", [])),
                "",
                "### Implementation Challenges",
                "",
                *_bullets(row.get("implementation_challenges", [])),
                "",
                "### Assumptions Requiring Confirmation",
                "",
                *_bullets(row.get("assumptions", [])),
                "",
            ]
        )
    return "\n".join(lines).strip() + "\n"


def render_stage_failure(stage_name: str, errors: Iterable[str]) -> str:
    lines = [
        f"# {stage_name}: Stage Failed",
        "",
        "> Warning: The language model did not produce a valid response after all configured attempts.",
        "> This file contains no model reasoning and must not be treated as a completed assessment.",
        "",
        "## Validation Errors",
        "",
    ]
    lines.extend(_bullets(errors))
    return "\n".join(lines).strip() + "\n"


def render_degraded_capabilities(data: Mapping[str, Any]) -> str:
    warning = _text(data.get("warning")) or (
        "The language model did not produce a valid capability-selection "
        "response after all attempts."
    )
    lines = [
        "# Step 2: Deterministic Degraded-Mode Capability Floor",
        "",
        f"> Warning: {warning}",
        "> The capabilities below were generated by deterministic DTAF rules and have not been validated by the model.",
        "",
    ]
    lines.extend(
        _table(
            ["Capability ID", "Name", "Priority", "Priority Source", "Reason"],
            [
                [
                    row.get("capability_id"),
                    row.get("name"),
                    row.get("priority"),
                    "deterministic_floor",
                    row.get("justification"),
                ]
                for row in data.get("capabilities", [])
            ],
        )
    )
    return "\n".join(lines).strip() + "\n"
