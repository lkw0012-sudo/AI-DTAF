"""Validated structured-output implementation of DTAF Steps 0–3."""

from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Set

from .contracts import (
    STEP0_SCHEMA,
    STEP1_SCHEMA,
    STEP2_SCHEMA,
    STEP3_SCHEMA,
    validate_step0,
    validate_step1,
    validate_step2,
    validate_step3,
)
from .lineage import build_traceability
from .registry import CapabilityRegistry
from .rendering import (
    render_stage_failure,
    render_step0,
    render_step1,
    render_step2,
    render_step3,
)
from .runner import StageRunResult, ValidatedStageRunner


PROMPT_TEMPLATE_VERSION = "dtaf-structured-v2.1"

StageModelCallable = Callable[
    [str, str, Sequence[Mapping[str, str]], Dict[str, Any], int], Any
]


@dataclass
class DTCStructuredResult:
    documents: Dict[str, Dict[str, Any]]
    stage_results: Dict[str, StageRunResult]
    pipeline_status: List[Dict[str, Any]]
    traceability: Dict[str, Any]

    @property
    def critical_failure(self) -> bool:
        return any(
            self.stage_results.get(stage) is None
            or self.stage_results[stage].data is None
            for stage in ("step1", "step2")
        )


def _json_dump(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2)


def _base_messages(task: str, context: str) -> List[Dict[str, str]]:
    return [
        {
            "role": "system",
            "content": (
                "You are the structured DTAF analyst. Return ONLY one complete JSON "
                "object matching the supplied JSON Schema. Never use Markdown tables. "
                "Do not invent current-state facts. Classify uncertainty explicitly, "
                "preserve stable identifiers, and use only supplied capability IDs."
            ),
        },
        {
            "role": "user",
            "content": f"{task}\n\nValidated context:\n{context}",
        },
    ]


def run_validated_dtc_pipeline(
    *,
    outdir: Path,
    sector: str,
    problem_statement: str,
    original_prompts: Mapping[str, str],
    registry: CapabilityRegistry,
    call_model: StageModelCallable,
    validation_retries: int,
    on_event: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> DTCStructuredResult:
    """Run structured Steps 0–3, saving raw and validated artifacts."""
    outdir = Path(outdir)
    raw_dir = outdir / "raw_model_responses"
    validated_dir = outdir / "validated"
    raw_dir.mkdir(parents=True, exist_ok=True)
    validated_dir.mkdir(parents=True, exist_ok=True)
    runner = ValidatedStageRunner(
        raw_dir=raw_dir,
        max_validation_retries=validation_retries,
        on_event=on_event,
    )
    docs: Dict[str, Dict[str, Any]] = {}
    results: Dict[str, StageRunResult] = {}
    statuses: List[Dict[str, Any]] = []

    def execute(
        *,
        key: str,
        display_name: str,
        schema: Dict[str, Any],
        messages: Sequence[Mapping[str, str]],
        validator: Callable[[Any], Dict[str, Any]],
        max_tokens: int,
        json_filename: str,
        markdown_filename: str,
        renderer: Callable[[Mapping[str, Any]], str],
    ) -> StageRunResult:
        result = runner.run(
            stage=key,
            base_messages=messages,
            schema=schema,
            validator=validator,
            call_model=lambda kind, attempt_messages, attempt_schema: call_model(
                key,
                kind,
                attempt_messages,
                attempt_schema,
                max_tokens,
            ),
            prompt_template_version=PROMPT_TEMPLATE_VERSION,
        )
        results[key] = result
        status_record = {
            "stage": key,
            "name": display_name,
            "status": result.status,
            "attempt_count": len(result.attempts),
            "validation_errors": list(result.validation_errors),
            "fallback_used": False,
            "output_path": markdown_filename,
        }
        statuses.append(status_record)
        if result.data is None:
            (outdir / markdown_filename).write_text(
                render_stage_failure(display_name, result.validation_errors),
                encoding="utf-8",
            )
        else:
            docs[key] = result.data
            (validated_dir / json_filename).write_text(
                _json_dump(result.data), encoding="utf-8"
            )
            (outdir / json_filename).write_text(
                _json_dump(result.data), encoding="utf-8"
            )
            (outdir / markdown_filename).write_text(
                renderer(result.data), encoding="utf-8"
            )
        return result

    step0_task = (
        "Assess use-case suitability for the stated sector. Organize challenges, "
        "root causes, impacts, trends, and actionable insights. Missing details must "
        "be listed as missing information. Return 2-5 distinct business areas and "
        "keep every field concise.\n\n"
        f"Original Step 0 instructions:\n{original_prompts.get('step0', '')}"
    )
    execute(
        key="step0",
        display_name="Step 0 Use-Case Suitability",
        schema=STEP0_SCHEMA,
        messages=_base_messages(
            step0_task,
            _json_dump({"sector": sector, "source_id": "USER-SECTOR"}),
        ),
        validator=validate_step0,
        max_tokens=3000,
        json_filename="step0_use_case_suitability.json",
        markdown_filename="step0_use_case_suitability.md",
        renderer=render_step0,
    )

    step1_task = (
        "Create a concise, use-case-specific requirement set. Use identifiers exactly "
        "like EVD-001, REQ-001, OBJ-001, KPI-001, DEC-001, and RSK-001. Produce "
        "3-8 requirements, 1-6 objectives, 1-6 KPIs, at most 6 decisions, and at "
        "most 6 risks. Consolidate related goals instead of creating one objective "
        "and KPI per sentence. A user_provided_fact is permitted only for an explicit "
        "present-state fact and must copy a verbatim source_excerpt from the user "
        "problem with source_refs=[\"USER-PROBLEM\"]. Treat phrases containing must, "
        "should, will, need, desired outcomes, proposed digital-twin functions, and "
        "future improvements as target_state with temporal_status target/planned/future, "
        "never as current evidence. Do not invent numeric KPI baselines or targets: "
        "use an explicit unknown requiring confirmation. Requirements must describe "
        "what this CNC use case needs—not generic analysis tasks such as 'provide "
        "business context'. Include the operational decisions the twin is intended "
        "to support. Put every unresolved prerequisite, baseline, target, owner, data "
        "interface, frequency, or acceptance threshold in missing_information.\n\n"
        f"Original Step 1 instructions:\n{original_prompts.get('step1', '')}"
    )
    step1 = execute(
        key="step1",
        display_name="Step 1 Business Requirements",
        schema=STEP1_SCHEMA,
        messages=_base_messages(
            step1_task,
            _json_dump(
                {
                    "sector": sector,
                    "problem_statement": problem_statement,
                    "problem_source_id": "USER-PROBLEM",
                    "validated_step0": docs.get("step0", {}),
                }
            ),
        ),
        validator=lambda data: validate_step1(
            data, problem_statement=problem_statement
        ),
        max_tokens=6000,
        json_filename="step1_business_requirements.json",
        markdown_filename="step1_business_requirements.md",
        renderer=render_step1,
    )

    if step1.data is None:
        for key, name, filename in (
            ("step2", "Step 2 Capability Selection", "step2_capability_selector.md"),
            ("step3", "Step 3 Capability Deep Dives", "step3_capability_deep_dives.md"),
        ):
            statuses.append(
                {
                    "stage": key,
                    "name": name,
                    "status": "skipped",
                    "attempt_count": 0,
                    "validation_errors": ["upstream_step1_failed"],
                    "fallback_used": False,
                    "output_path": filename,
                }
            )
            (outdir / filename).write_text(
                render_stage_failure(name, ["upstream_step1_failed"]),
                encoding="utf-8",
            )
        return DTCStructuredResult(docs, results, statuses, {})

    req_ids = {
        row["requirement_id"] for row in docs["step1"].get("requirements", [])
    }
    step2_task = (
        "Select only capabilities needed for the validated requirements. Use only "
        "IDs from the canonical registry. Every capability must reference one or "
        "more REQ IDs and receive exactly one E/H/F priority. Do not return an empty "
        "selection and do not classify the entire catalog by default. Select a "
        "focused set of no more than 24 capabilities; implementation assumptions "
        "must be explicit. E means indispensable to the stated first usable twin, "
        "H means valuable after the essential foundation, and F means optional or "
        "future. Do not select a capability merely because it is generally useful. "
        "For example, select Search only when a validated requirement explicitly "
        "needs search, query, or retrieval, and select XR only when immersive or "
        "spatial interaction is requested. Select Federated Learning only when a "
        "requirement establishes distributed data, data sovereignty, or an inability "
        "to centralize training data. Select Advanced Visualization only when a "
        "requirement asks for advanced visual analytics, 3D, or immersive interaction. "
        "Capabilities directly required by an "
        "explicit user target—such as prediction, simulation, or automated decision "
        "support—must not be demoted below E without a requirement-specific reason. "
        "Before returning JSON, internally audit every selection against its cited "
        "REQ IDs and remove generic extras.\n\n"
        f"Original Step 2 instructions:\n{original_prompts.get('step2', '')}"
    )
    step2_schema = deepcopy(STEP2_SCHEMA)
    step2_schema["properties"]["capabilities"]["items"]["properties"][
        "capability_id"
    ]["enum"] = sorted(registry.ids)
    step2 = execute(
        key="step2",
        display_name="Step 2 Capability Selection",
        schema=step2_schema,
        messages=_base_messages(
            step2_task,
            _json_dump(
                {
                    "validated_step1": docs["step1"],
                    "canonical_cpt_capabilities": registry.to_list(),
                }
            ),
        ),
        validator=lambda data: validate_step2(
            data,
            capability_ids=registry.ids,
            requirement_ids=req_ids,
            selection_context=(
                problem_statement + "\n" + _json_dump(docs["step1"])
            ),
            normalize_unsupported_contextual=True,
        ),
        max_tokens=5000,
        json_filename="step2_capability_selection.json",
        markdown_filename="step2_capability_selector.md",
        renderer=render_step2,
    )
    if step2.data is not None:
        priority_source = step2.priority_source
        deterministic_priority_ids = {
            row.get("capability_id")
            for row in docs["step2"].get("selection_normalizations", [])
            if row.get("action") == "raised_priority_for_explicit_requirement"
        }
        for capability in docs["step2"].get("capabilities", []):
            capability["name"] = registry.get(capability["capability_id"]).name
            capability["priority_source"] = (
                "deterministic_floor"
                if capability["capability_id"] in deterministic_priority_ids
                else priority_source
            )
        (validated_dir / "step2_capability_selection.json").write_text(
            _json_dump(docs["step2"]), encoding="utf-8"
        )
        (outdir / "step2_capability_selection.json").write_text(
            _json_dump(docs["step2"]), encoding="utf-8"
        )
        (outdir / "step2_capability_selector.md").write_text(
            render_step2(docs["step2"]), encoding="utf-8"
        )

    if step2.data is None:
        statuses.append(
            {
                "stage": "step3",
                "name": "Step 3 Capability Deep Dives",
                "status": "skipped",
                "attempt_count": 0,
                "validation_errors": ["upstream_step2_failed"],
                "fallback_used": False,
                "output_path": "step3_capability_deep_dives.md",
            }
        )
        (outdir / "step3_capability_deep_dives.md").write_text(
            render_stage_failure(
                "Step 3 Capability Deep Dives", ["upstream_step2_failed"]
            ),
            encoding="utf-8",
        )
        return DTCStructuredResult(docs, results, statuses, {})

    selected_ids = {
        row["capability_id"] for row in docs["step2"].get("capabilities", [])
    }
    approved_cross_cutting = {
        capability_id for capability_id in registry.ids if capability_id.startswith("TW.")
    }
    step3_task = (
        "Deep-dive the most important selected capabilities. A capability not selected "
        "in Step 2 is allowed only when selection_basis is cross_cutting_mandatory and "
        "it is a canonical TW capability. Reference only existing REQ IDs. Consolidate "
        "the analysis into at most 10 high-value deep dives and keep criteria measurable "
        "without inventing unsupported numeric thresholds.\n\n"
        f"Original Step 3 part 1 instructions:\n{original_prompts.get('step3_part1', '')}\n\n"
        f"Original Step 3 part 2 instructions:\n{original_prompts.get('step3_part2', '')}"
    )
    execute(
        key="step3",
        display_name="Step 3 Capability Deep Dives",
        schema=STEP3_SCHEMA,
        messages=_base_messages(
            step3_task,
            _json_dump(
                {
                    "validated_requirements": docs["step1"],
                    "validated_capability_selection": docs["step2"],
                    "approved_cross_cutting_capability_ids": sorted(
                        approved_cross_cutting
                    ),
                }
            ),
        ),
        validator=lambda data: validate_step3(
            data,
            capability_ids=registry.ids,
            selected_capability_ids=selected_ids,
            requirement_ids=req_ids,
            cross_cutting_capability_ids=approved_cross_cutting,
        ),
        max_tokens=6000,
        json_filename="step3_capability_deep_dives.json",
        markdown_filename="step3_capability_deep_dives.md",
        renderer=render_step3,
    )
    if "step3" in docs:
        for row in docs["step3"].get("deep_dives", []):
            row["name"] = registry.get(row["capability_id"]).name
        (validated_dir / "step3_capability_deep_dives.json").write_text(
            _json_dump(docs["step3"]), encoding="utf-8"
        )
        (outdir / "step3_capability_deep_dives.json").write_text(
            _json_dump(docs["step3"]), encoding="utf-8"
        )
        rendered = render_step3(docs["step3"])
        (outdir / "step3_capability_deep_dives.md").write_text(
            rendered, encoding="utf-8"
        )
        (outdir / "step3_part1.md").write_text(rendered, encoding="utf-8")
        (outdir / "step3_part2.md").write_text(rendered, encoding="utf-8")

    traceability = build_traceability(
        step1=docs["step1"],
        step2=docs["step2"],
        step3=docs.get("step3", {}),
    )
    (outdir / "traceability.json").write_text(
        _json_dump(traceability), encoding="utf-8"
    )
    return DTCStructuredResult(docs, results, statuses, traceability)
