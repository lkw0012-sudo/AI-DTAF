"""Schemas and pure validation functions for model-produced DTAF data.

The JSON Schema dictionaries are sent to models, but DTAF never trusts schema
prompts alone.  Every response is parsed and validated again in Python.
"""

from __future__ import annotations

import json
import re
from copy import deepcopy
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Set


FOURR_LEVEL_NAMES: Dict[str, str] = {
    "R1": "Representation",
    "R2": "Replication",
    "R3": "Reality",
    "R4": "Relational",
}

FOURS_LEVEL_NAMES: Dict[str, str] = {
    "S1": "Modeling",
    "S2": "Analyzing",
    "S3": "Predicting",
    "S4": "Prescribing",
}

FOURR_TO_MAX_FOURS: Dict[str, str] = {
    "R1": "S1",
    "R2": "S2",
    "R3": "S3",
    "R4": "S4",
}

STATEMENT_TYPES: Set[str] = {
    "user_provided_fact",
    "source_derived_fact",
    "assumption",
    "recommendation",
    "target_state",
    "current_state_evidence",
    "unknown_requires_confirmation",
}

TEMPORAL_STATUSES: Set[str] = {"current", "planned", "target", "future", "unknown"}
PRIORITIES: Set[str] = {"E", "H", "F"}

REQUIREMENT_CATEGORIES: Set[str] = {
    "business",
    "operational",
    "data",
    "user_experience",
    "technical",
    "security",
    "governance",
    "implementation",
}

PRIORITY_SOURCES: Set[str] = {
    "model",
    "model_repair",
    "deterministic_floor",
    "user_override",
}

PREREQUISITE_STATES: Set[str] = {
    "confirmed_available",
    "partially_available",
    "unknown",
    "missing",
    "not_applicable",
}

STAGE_STATUSES: Set[str] = {
    "successful",
    "repaired",
    "fallback_used",
    "degraded",
    "failed",
    "skipped",
}

_ID_PATTERNS: Dict[str, re.Pattern[str]] = {
    "requirement": re.compile(r"^REQ-\d{3,}$"),
    "objective": re.compile(r"^OBJ-\d{3,}$"),
    "kpi": re.compile(r"^KPI-\d{3,}$"),
    "evidence": re.compile(r"^EVD-\d{3,}$"),
    "assumption": re.compile(r"^ASM-\d{3,}$"),
    "decision": re.compile(r"^DEC-\d{3,}$"),
    "risk": re.compile(r"^RSK-\d{3,}$"),
    "validation": re.compile(r"^VNV-\d{3,}$"),
}

_PLACEHOLDER_PATTERNS: Sequence[re.Pattern[str]] = (
    re.compile(r"\b(?:primary|related|candidate|selected)\s+\w+\s*\[\s*\d+\s*\]", re.I),
    re.compile(r"\b(?:tbd|todo|lorem ipsum|placeholder text|insert .+ here)\b", re.I),
    re.compile(r"^\s*(?:none|null|n/?a)\s*$", re.I),
    re.compile(r"\{\{\s*[^{}]+\s*\}\}"),
)

_FUTURE_MARKERS = re.compile(
    r"\b(?:will|would|should|shall|must|need(?:ed|s)?|plan(?:ned|s|ning)?|propos(?:e|ed)|target|"
    r"future|intend(?:ed|s)?|recommend(?:ed|s|ation)?|to be|aim(?:s|ed)? to|"
    r"could|may eventually|envision(?:ed|s)?)\b",
    re.I,
)

_MARKDOWN_SEPARATOR_CELL = re.compile(r"^:?-{3,}:?$")


class PipelineContractError(ValueError):
    """A model response failed one or more structural or semantic contracts."""

    def __init__(self, errors: Iterable[str], *, stage: str = "") -> None:
        self.errors = [str(error) for error in errors if str(error).strip()]
        self.stage = stage
        prefix = f"{stage}: " if stage else ""
        super().__init__(prefix + "; ".join(self.errors))


def _array_schema(
    item_schema: Dict[str, Any],
    *,
    minimum: int = 0,
    maximum: Optional[int] = None,
) -> Dict[str, Any]:
    schema: Dict[str, Any] = {"type": "array", "items": item_schema}
    if minimum:
        schema["minItems"] = minimum
    if maximum is not None:
        schema["maxItems"] = maximum
    return schema


STRING_ARRAY_SCHEMA: Dict[str, Any] = _array_schema(
    {"type": "string", "maxLength": 500}, maximum=12
)


def _id_schema(prefix: str) -> Dict[str, Any]:
    return {
        "type": "string",
        "pattern": rf"^{prefix}-[0-9]{{3,}}$",
    }

STATEMENT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "statement_id": _id_schema("EVD"),
        "text": {"type": "string", "maxLength": 700},
        "statement_type": {"type": "string", "enum": sorted(STATEMENT_TYPES)},
        "temporal_status": {"type": "string", "enum": sorted(TEMPORAL_STATUSES)},
        "source_refs": STRING_ARRAY_SCHEMA,
        "source_excerpt": {"type": "string", "maxLength": 500},
        "confirmation_required": {"type": "boolean"},
    },
    "required": [
        "statement_id",
        "text",
        "statement_type",
        "temporal_status",
        "source_refs",
        "source_excerpt",
        "confirmation_required",
    ],
    "additionalProperties": False,
}

STEP0_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "suitability_summary": {"type": "string"},
        "business_areas": _array_schema(
            {
                "type": "object",
                "properties": {
                    "area_id": {"type": "string"},
                    "name": {"type": "string"},
                    "challenges": STRING_ARRAY_SCHEMA,
                    "root_causes": STRING_ARRAY_SCHEMA,
                    "business_impacts": STRING_ARRAY_SCHEMA,
                    "trends_or_disruptions": STRING_ARRAY_SCHEMA,
                    "actionable_insights": STRING_ARRAY_SCHEMA,
                },
                "required": [
                    "area_id",
                    "name",
                    "challenges",
                    "root_causes",
                    "business_impacts",
                    "trends_or_disruptions",
                    "actionable_insights",
                ],
                "additionalProperties": False,
            },
            minimum=2,
            maximum=6,
        ),
        "missing_information": STRING_ARRAY_SCHEMA,
    },
    "required": ["suitability_summary", "business_areas", "missing_information"],
    "additionalProperties": False,
}

STEP1_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "business_context": {"type": "string"},
        "statements": _array_schema(STATEMENT_SCHEMA, minimum=1, maximum=8),
        "requirements": _array_schema(
            {
                "type": "object",
                "properties": {
                    "requirement_id": _id_schema("REQ"),
                    "title": {"type": "string", "maxLength": 180},
                    "description": {"type": "string", "maxLength": 800},
                    "category": {"type": "string", "enum": sorted(REQUIREMENT_CATEGORIES)},
                    "statement_type": {"type": "string", "enum": sorted(STATEMENT_TYPES)},
                    "temporal_status": {"type": "string", "enum": sorted(TEMPORAL_STATUSES)},
                    "source_refs": STRING_ARRAY_SCHEMA,
                    "source_excerpt": {"type": "string", "maxLength": 500},
                    "confirmation_required": {"type": "boolean"},
                },
                "required": [
                    "requirement_id",
                    "title",
                    "description",
                    "category",
                    "statement_type",
                    "temporal_status",
                    "source_refs",
                    "source_excerpt",
                    "confirmation_required",
                ],
                "additionalProperties": False,
            },
            minimum=3,
            maximum=8,
        ),
        "objectives": _array_schema(
            {
                "type": "object",
                "properties": {
                    "objective_id": _id_schema("OBJ"),
                    "description": {"type": "string", "maxLength": 600},
                    "related_requirement_ids": STRING_ARRAY_SCHEMA,
                    "statement_type": {"type": "string", "enum": sorted(STATEMENT_TYPES)},
                    "temporal_status": {"type": "string", "enum": sorted(TEMPORAL_STATUSES)},
                },
                "required": [
                    "objective_id",
                    "description",
                    "related_requirement_ids",
                    "statement_type",
                    "temporal_status",
                ],
                "additionalProperties": False,
            },
            minimum=1,
            maximum=6,
        ),
        "kpis": _array_schema(
            {
                "type": "object",
                "properties": {
                    "kpi_id": _id_schema("KPI"),
                    "name": {"type": "string", "maxLength": 180},
                    "measurement": {"type": "string", "maxLength": 500},
                    "baseline": {"type": "string", "maxLength": 300},
                    "target": {"type": "string", "maxLength": 300},
                    "related_objective_ids": STRING_ARRAY_SCHEMA,
                    "confirmation_required": {"type": "boolean"},
                },
                "required": [
                    "kpi_id",
                    "name",
                    "measurement",
                    "baseline",
                    "target",
                    "related_objective_ids",
                    "confirmation_required",
                ],
                "additionalProperties": False,
            },
            minimum=1,
            maximum=6,
        ),
        "decisions": _array_schema(
            {
                "type": "object",
                "properties": {
                    "decision_id": _id_schema("DEC"),
                    "description": {"type": "string", "maxLength": 600},
                    "related_requirement_ids": STRING_ARRAY_SCHEMA,
                },
                "required": ["decision_id", "description", "related_requirement_ids"],
                "additionalProperties": False,
            },
            maximum=6,
        ),
        "risks": _array_schema(
            {
                "type": "object",
                "properties": {
                    "risk_id": _id_schema("RSK"),
                    "description": {"type": "string", "maxLength": 600},
                    "mitigation": {"type": "string", "maxLength": 600},
                    "related_requirement_ids": STRING_ARRAY_SCHEMA,
                },
                "required": ["risk_id", "description", "mitigation", "related_requirement_ids"],
                "additionalProperties": False,
            },
            maximum=6,
        ),
        "missing_information": STRING_ARRAY_SCHEMA,
    },
    "required": [
        "business_context",
        "statements",
        "requirements",
        "objectives",
        "kpis",
        "decisions",
        "risks",
        "missing_information",
    ],
    "additionalProperties": False,
}

STEP2_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "capabilities": _array_schema(
            {
                "type": "object",
                "properties": {
                    "capability_id": {
                        "type": "string",
                        "pattern": "^[A-Z]{2}\\.[A-Z0-9]{2}$",
                    },
                    "priority": {"type": "string", "enum": ["E", "H", "F"]},
                    "justification": {"type": "string"},
                    "related_requirement_ids": _array_schema({"type": "string"}, minimum=1),
                    "deployment_considerations": {"type": "string"},
                    "assumptions": STRING_ARRAY_SCHEMA,
                },
                "required": [
                    "capability_id",
                    "priority",
                    "justification",
                    "related_requirement_ids",
                    "deployment_considerations",
                    "assumptions",
                ],
                "additionalProperties": False,
            },
            minimum=1,
            maximum=24,
        ),
        "capability_gaps": STRING_ARRAY_SCHEMA,
        "implementation_phases": STRING_ARRAY_SCHEMA,
        "specialized_expertise": STRING_ARRAY_SCHEMA,
    },
    "required": [
        "capabilities",
        "capability_gaps",
        "implementation_phases",
        "specialized_expertise",
    ],
    "additionalProperties": False,
}

STEP3_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "deep_dives": _array_schema(
            {
                "type": "object",
                "properties": {
                    "capability_id": {"type": "string"},
                    "selection_basis": {
                        "type": "string",
                        "enum": ["selected", "cross_cutting_mandatory"],
                    },
                    "related_requirement_ids": _array_schema({"type": "string"}, minimum=1),
                    "specific_requirements": _array_schema({"type": "string"}, minimum=1),
                    "success_criteria": _array_schema({"type": "string"}, minimum=1),
                    "technology_approaches": _array_schema({"type": "string"}, minimum=1),
                    "implementation_challenges": _array_schema({"type": "string"}, minimum=1),
                    "assumptions": STRING_ARRAY_SCHEMA,
                },
                "required": [
                    "capability_id",
                    "selection_basis",
                    "related_requirement_ids",
                    "specific_requirements",
                    "success_criteria",
                    "technology_approaches",
                    "implementation_challenges",
                    "assumptions",
                ],
                "additionalProperties": False,
            },
            minimum=1,
            maximum=10,
        )
    },
    "required": ["deep_dives"],
    "additionalProperties": False,
}

DTC_STAGE_SCHEMAS: Dict[str, Dict[str, Any]] = {
    "0": STEP0_SCHEMA,
    "1": STEP1_SCHEMA,
    "2": STEP2_SCHEMA,
    "3": STEP3_SCHEMA,
}


def parse_json_response(text: str) -> Any:
    """Parse a complete JSON response and reject prose or truncated JSON."""
    value = str(text or "").strip()
    fence = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", value, flags=re.I | re.S)
    if fence:
        value = fence.group(1).strip()
    if not value:
        raise PipelineContractError(["empty_response"])
    try:
        return json.loads(value)
    except json.JSONDecodeError as exc:
        category = "truncated_json" if _looks_truncated_json(value) else "malformed_json"
        raise PipelineContractError(
            [f"{category}: line {exc.lineno} column {exc.colno}: {exc.msg}"]
        ) from exc


def _looks_truncated_json(text: str) -> bool:
    stripped = text.rstrip()
    if not stripped:
        return False
    pairs = {"{": "}", "[": "]"}
    stack: List[str] = []
    in_string = False
    escaped = False
    for char in stripped:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in pairs:
            stack.append(pairs[char])
        elif char in {"}", "]"}:
            if not stack or stack[-1] != char:
                return False
            stack.pop()
    return bool(stack or in_string or stripped.endswith((",", ":", "\\")))


def _is_separator_row(line: str) -> bool:
    cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
    return bool(cells) and all(_MARKDOWN_SEPARATOR_CELL.fullmatch(cell) for cell in cells)


def incomplete_response_errors(
    text: str,
    *,
    required_headings: Optional[Sequence[str]] = None,
    minimum_characters: int = 0,
    data_rows_required: bool = True,
) -> List[str]:
    """Return structural errors for commonly truncated Markdown or JSON text."""
    value = str(text or "")
    stripped = value.strip()
    errors: List[str] = []
    if not stripped:
        return ["empty_response"]
    if minimum_characters and len(stripped) < minimum_characters:
        errors.append(
            f"response_too_short: {len(stripped)} < {minimum_characters} characters"
        )
    if stripped.count("```") % 2:
        errors.append("unclosed_code_block")
    if stripped.startswith(("{", "[")):
        try:
            json.loads(stripped)
        except json.JSONDecodeError:
            errors.append(
                "truncated_json" if _looks_truncated_json(stripped) else "malformed_json"
            )

    lines = value.splitlines()
    index = 0
    while index < len(lines):
        if not lines[index].lstrip().startswith("|"):
            index += 1
            continue
        block: List[str] = []
        while index < len(lines) and lines[index].lstrip().startswith("|"):
            block.append(lines[index].strip())
            index += 1
        if len(block) == 1:
            errors.append("markdown_table_header_without_separator")
            continue
        if not _is_separator_row(block[1]):
            errors.append("markdown_table_header_without_separator")
            continue
        if data_rows_required and len(block) < 3:
            errors.append("markdown_table_separator_without_data_rows")

    if stripped.endswith("|") or (
        lines and lines[-1].lstrip().startswith("|") and not _is_separator_row(lines[-1])
    ):
        last_line = lines[-1] if lines else stripped
        if last_line.count("|") >= 1 and not _is_separator_row(last_line):
            previous_is_separator = len(lines) >= 2 and _is_separator_row(lines[-2])
            if not previous_is_separator:
                errors.append("response_ends_with_pipe_delimited_header")

    lower = stripped.casefold()
    for heading in required_headings or ():
        if str(heading).strip().casefold() not in lower:
            errors.append(f"missing_required_heading: {heading}")
    return _dedupe(errors)


def contains_placeholder(value: Any) -> bool:
    """Detect literal template placeholders and index references."""
    if isinstance(value, Mapping):
        return any(contains_placeholder(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return any(contains_placeholder(item) for item in value)
    text = str(value or "")
    return any(pattern.search(text) for pattern in _PLACEHOLDER_PATTERNS)


def temporal_status_for_text(text: str) -> str:
    """Classify obvious future/target language so it cannot count as current evidence."""
    value = str(text or "").strip()
    if not value:
        return "unknown"
    if _FUTURE_MARKERS.search(value):
        if re.search(r"\btarget\b", value, re.I):
            return "target"
        if re.search(r"\bfuture\b", value, re.I):
            return "future"
        return "planned"
    return "current"


def is_current_evidence(statement_type: str, temporal_status: str, text: str = "") -> bool:
    """True only for explicit current-state facts or evidence."""
    kind = str(statement_type or "").strip()
    temporal = str(temporal_status or "").strip()
    if temporal != "current" or temporal_status_for_text(text) != "current":
        return False
    return kind in {
        "user_provided_fact",
        "source_derived_fact",
        "current_state_evidence",
    }


def _require_object(data: Any, stage: str) -> Dict[str, Any]:
    if not isinstance(data, dict):
        raise PipelineContractError(["top_level_must_be_object"], stage=stage)
    return deepcopy(data)


def _require_nonempty_string(
    obj: Mapping[str, Any], key: str, errors: List[str], prefix: str
) -> str:
    value = str(obj.get(key, "") or "").strip()
    if not value:
        errors.append(f"{prefix}.{key}: missing_or_empty")
    elif contains_placeholder(value):
        errors.append(f"{prefix}.{key}: placeholder_detected")
    return value


def _require_string_list(
    obj: Mapping[str, Any],
    key: str,
    errors: List[str],
    prefix: str,
    *,
    minimum: int = 0,
) -> List[str]:
    value = obj.get(key)
    if not isinstance(value, list):
        errors.append(f"{prefix}.{key}: must_be_array")
        return []
    cleaned = [str(item).strip() for item in value if str(item).strip()]
    if len(cleaned) < minimum:
        errors.append(f"{prefix}.{key}: requires_at_least_{minimum}_items")
    if any(contains_placeholder(item) for item in cleaned):
        errors.append(f"{prefix}.{key}: placeholder_detected")
    return cleaned


def _validate_unique_ids(
    rows: Sequence[Mapping[str, Any]],
    key: str,
    kind: str,
    errors: List[str],
) -> Set[str]:
    pattern = _ID_PATTERNS[kind]
    seen: Set[str] = set()
    for index, row in enumerate(rows):
        value = str(row.get(key, "") or "").strip()
        if not pattern.fullmatch(value):
            errors.append(f"{key}[{index}]: malformed_identifier: {value!r}")
        if value in seen:
            errors.append(f"{key}[{index}]: duplicate_identifier: {value}")
        if value:
            seen.add(value)
    return seen


def _normalize_source_excerpt(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def _validate_grounded_statement(
    row: Mapping[str, Any],
    *,
    problem_statement: str,
    prefix: str,
    errors: List[str],
) -> None:
    statement_type = str(row.get("statement_type", "")).strip()
    temporal = str(row.get("temporal_status", "")).strip()
    text = str(row.get("text", row.get("description", "")) or "").strip()
    excerpt = str(row.get("source_excerpt", "") or "").strip()
    refs = row.get("source_refs", [])
    if statement_type not in STATEMENT_TYPES:
        errors.append(f"{prefix}.statement_type: invalid_enum: {statement_type}")
    if temporal not in TEMPORAL_STATUSES:
        errors.append(f"{prefix}.temporal_status: invalid_enum: {temporal}")
    if not isinstance(refs, list):
        errors.append(f"{prefix}.source_refs: must_be_array")
        refs = []
    if not text:
        errors.append(f"{prefix}.text: missing_or_empty")
    if contains_placeholder(text):
        errors.append(f"{prefix}.text: placeholder_detected")

    if statement_type == "user_provided_fact":
        normalized_problem = _normalize_source_excerpt(problem_statement)
        normalized_excerpt = _normalize_source_excerpt(excerpt)
        if not normalized_excerpt or normalized_excerpt not in normalized_problem:
            errors.append(
                f"{prefix}: user_provided_fact_requires_verbatim_source_excerpt"
            )
        if "USER-PROBLEM" not in {str(item).strip() for item in refs}:
            errors.append(f"{prefix}: user_provided_fact_requires_USER-PROBLEM_ref")
    if statement_type in {"assumption", "unknown_requires_confirmation"}:
        if not bool(row.get("confirmation_required", False)):
            errors.append(f"{prefix}: assumption_or_unknown_requires_confirmation")
    if statement_type in {"target_state", "recommendation"} and temporal == "current":
        errors.append(f"{prefix}: target_or_recommendation_cannot_be_current")
    if temporal == "current" and temporal_status_for_text(text) != "current":
        errors.append(f"{prefix}: future_language_cannot_be_current_evidence")


def _canonicalize_generated_id(value: Any, kind: str) -> str:
    """Normalize only unambiguous, local-model ID formatting near misses."""
    raw = str(value or "").strip().upper()
    if _ID_PATTERNS[kind].fullmatch(raw):
        return raw
    aliases = {
        "evidence": ("EVD", "S"),
        "requirement": ("REQ",),
        "objective": ("OBJ",),
        "kpi": ("KPI",),
        "decision": ("DEC",),
        "risk": ("RSK", "RISK"),
    }
    canonical_prefix = {
        "evidence": "EVD",
        "requirement": "REQ",
        "objective": "OBJ",
        "kpi": "KPI",
        "decision": "DEC",
        "risk": "RSK",
    }
    for alias in aliases.get(kind, ()):
        match = re.fullmatch(rf"{alias}[-_ ]?(\d+)", raw)
        if match:
            return f"{canonical_prefix[kind]}-{int(match.group(1)):03d}"
    return raw


def normalize_step1_output(data: Any) -> Any:
    """Repair safe Step 1 formatting and temporal-classification near misses.

    Every change is recorded in ``normalizations``. The function never invents
    an identifier relationship or promotes target language to current evidence.
    """
    if not isinstance(data, dict):
        return data
    obj = deepcopy(data)
    normalizations: List[Dict[str, str]] = []
    id_maps: Dict[str, Dict[str, str]] = {
        "requirement": {},
        "objective": {},
    }
    specs = (
        ("statements", "statement_id", "evidence"),
        ("requirements", "requirement_id", "requirement"),
        ("objectives", "objective_id", "objective"),
        ("kpis", "kpi_id", "kpi"),
        ("decisions", "decision_id", "decision"),
        ("risks", "risk_id", "risk"),
    )
    for collection, field, kind in specs:
        for index, row in enumerate(obj.get(collection, []) or []):
            if not isinstance(row, dict):
                continue
            old = str(row.get(field, "") or "").strip()
            new = _canonicalize_generated_id(old, kind)
            if old != new:
                row[field] = new
                normalizations.append(
                    {
                        "field": f"{collection}[{index}].{field}",
                        "from": old,
                        "to": new,
                        "reason": "unambiguous_identifier_format",
                    }
                )
            if kind in id_maps and old:
                id_maps[kind][old] = new
                id_maps[kind][old.upper()] = new

    def rewrite_refs(
        collection: str,
        field: str,
        reference_kind: str,
    ) -> None:
        mapping = id_maps[reference_kind]
        for index, row in enumerate(obj.get(collection, []) or []):
            if not isinstance(row, dict) or not isinstance(row.get(field), list):
                continue
            old_refs = [str(value).strip() for value in row[field]]
            new_refs = [
                mapping.get(value, mapping.get(value.upper(), value))
                for value in old_refs
            ]
            if old_refs != new_refs:
                row[field] = new_refs
                normalizations.append(
                    {
                        "field": f"{collection}[{index}].{field}",
                        "from": ", ".join(old_refs),
                        "to": ", ".join(new_refs),
                        "reason": "identifier_reference_alignment",
                    }
                )

    for collection in ("objectives", "decisions", "risks"):
        rewrite_refs(collection, "related_requirement_ids", "requirement")
    rewrite_refs("kpis", "related_objective_ids", "objective")

    for collection in ("statements", "requirements"):
        for index, row in enumerate(obj.get(collection, []) or []):
            if not isinstance(row, dict):
                continue
            text = str(row.get("text", row.get("description", "")) or "")
            kind = str(row.get("statement_type", "") or "")
            temporal = str(row.get("temporal_status", "") or "")
            inferred_temporal = temporal_status_for_text(text)
            if (
                kind == "user_provided_fact"
                and temporal == "current"
                and inferred_temporal != "current"
            ):
                row["statement_type"] = "target_state"
                row["temporal_status"] = (
                    inferred_temporal
                    if inferred_temporal in {"planned", "target", "future"}
                    else "target"
                )
                normalizations.append(
                    {
                        "field": f"{collection}[{index}].statement_type/temporal_status",
                        "from": "user_provided_fact/current",
                        "to": f"target_state/{row['temporal_status']}",
                        "reason": "future_language_cannot_be_current_evidence",
                    }
                )
            if str(row.get("statement_type", "")) in {
                "assumption",
                "unknown_requires_confirmation",
            } and not bool(row.get("confirmation_required", False)):
                row["confirmation_required"] = True
                normalizations.append(
                    {
                        "field": f"{collection}[{index}].confirmation_required",
                        "from": "false",
                        "to": "true",
                        "reason": "assumption_requires_confirmation",
                    }
                )
    if normalizations:
        obj["normalizations"] = [
            *[
                row
                for row in obj.get("normalizations", [])
                if isinstance(row, dict)
            ],
            *normalizations,
        ]
    return obj


def validate_step0(data: Any) -> Dict[str, Any]:
    obj = _require_object(data, "step0")
    errors: List[str] = []
    _require_nonempty_string(obj, "suitability_summary", errors, "step0")
    areas = obj.get("business_areas")
    if not isinstance(areas, list):
        errors.append("step0.business_areas: must_be_array")
        areas = []
    if len(areas) < 2:
        errors.append("step0.business_areas: requires_at_least_2_items")
    if len(areas) > 6:
        errors.append("step0.business_areas: maximum_6_items")
    seen: Set[str] = set()
    for index, area in enumerate(areas):
        prefix = f"step0.business_areas[{index}]"
        if not isinstance(area, dict):
            errors.append(f"{prefix}: must_be_object")
            continue
        area_id = _require_nonempty_string(area, "area_id", errors, prefix)
        if area_id in seen:
            errors.append(f"{prefix}.area_id: duplicate_identifier")
        seen.add(area_id)
        _require_nonempty_string(area, "name", errors, prefix)
        for key in (
            "challenges",
            "root_causes",
            "business_impacts",
            "trends_or_disruptions",
            "actionable_insights",
        ):
            _require_string_list(area, key, errors, prefix, minimum=1)
    _require_string_list(obj, "missing_information", errors, "step0")
    if errors:
        raise PipelineContractError(errors, stage="step0")
    return obj


def validate_step1(data: Any, *, problem_statement: str) -> Dict[str, Any]:
    obj = _require_object(normalize_step1_output(data), "step1")
    errors: List[str] = []
    _require_nonempty_string(obj, "business_context", errors, "step1")

    statements = obj.get("statements")
    if not isinstance(statements, list):
        errors.append("step1.statements: must_be_array")
        statements = []
    if len(statements) > 8:
        errors.append("step1.statements: maximum_8_items")
    _validate_unique_ids(
        [row for row in statements if isinstance(row, dict)],
        "statement_id",
        "evidence",
        errors,
    )
    for index, row in enumerate(statements):
        if not isinstance(row, dict):
            errors.append(f"step1.statements[{index}]: must_be_object")
            continue
        _validate_grounded_statement(
            row,
            problem_statement=problem_statement,
            prefix=f"step1.statements[{index}]",
            errors=errors,
        )

    requirements = obj.get("requirements")
    if not isinstance(requirements, list):
        errors.append("step1.requirements: must_be_array")
        requirements = []
    if len(requirements) < 3:
        errors.append("step1.requirements: requires_at_least_3_items")
    if len(requirements) > 8:
        errors.append("step1.requirements: maximum_8_items")
    req_ids = _validate_unique_ids(
        [row for row in requirements if isinstance(row, dict)],
        "requirement_id",
        "requirement",
        errors,
    )
    for index, row in enumerate(requirements):
        prefix = f"step1.requirements[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{prefix}: must_be_object")
            continue
        _require_nonempty_string(row, "title", errors, prefix)
        _require_nonempty_string(row, "description", errors, prefix)
        if str(row.get("category", "")).strip() not in REQUIREMENT_CATEGORIES:
            errors.append(f"{prefix}.category: invalid_enum")
        _validate_grounded_statement(
            row,
            problem_statement=problem_statement,
            prefix=prefix,
            errors=errors,
        )

    objectives = obj.get("objectives")
    if not isinstance(objectives, list):
        errors.append("step1.objectives: must_be_array")
        objectives = []
    if not objectives:
        errors.append("step1.objectives: requires_at_least_1_item")
    if len(objectives) > 6:
        errors.append("step1.objectives: maximum_6_items")
    objective_ids = _validate_unique_ids(
        [row for row in objectives if isinstance(row, dict)],
        "objective_id",
        "objective",
        errors,
    )
    for index, row in enumerate(objectives):
        prefix = f"step1.objectives[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{prefix}: must_be_object")
            continue
        _require_nonempty_string(row, "description", errors, prefix)
        related = _require_string_list(
            row, "related_requirement_ids", errors, prefix, minimum=1
        )
        for ref in related:
            if ref not in req_ids:
                errors.append(f"{prefix}: unknown_requirement_reference: {ref}")
        if str(row.get("statement_type", "")).strip() not in STATEMENT_TYPES:
            errors.append(f"{prefix}.statement_type: invalid_enum")
        temporal = str(row.get("temporal_status", "")).strip()
        if temporal not in TEMPORAL_STATUSES:
            errors.append(f"{prefix}.temporal_status: invalid_enum")

    kpis = obj.get("kpis")
    if not isinstance(kpis, list):
        errors.append("step1.kpis: must_be_array")
        kpis = []
    if not kpis:
        errors.append("step1.kpis: requires_at_least_1_item")
    if len(kpis) > 6:
        errors.append("step1.kpis: maximum_6_items")
    _validate_unique_ids(
        [row for row in kpis if isinstance(row, dict)],
        "kpi_id",
        "kpi",
        errors,
    )
    for index, row in enumerate(kpis):
        prefix = f"step1.kpis[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{prefix}: must_be_object")
            continue
        for key in ("name", "measurement", "baseline", "target"):
            _require_nonempty_string(row, key, errors, prefix)
        related = _require_string_list(
            row, "related_objective_ids", errors, prefix, minimum=1
        )
        for ref in related:
            if ref not in objective_ids:
                errors.append(f"{prefix}: unknown_objective_reference: {ref}")

    for collection, key, kind in (
        ("decisions", "decision_id", "decision"),
        ("risks", "risk_id", "risk"),
    ):
        rows = obj.get(collection)
        if not isinstance(rows, list):
            errors.append(f"step1.{collection}: must_be_array")
            continue
        if len(rows) > 6:
            errors.append(f"step1.{collection}: maximum_6_items")
        _validate_unique_ids(
            [row for row in rows if isinstance(row, dict)], key, kind, errors
        )
        for index, row in enumerate(rows):
            prefix = f"step1.{collection}[{index}]"
            if not isinstance(row, dict):
                errors.append(f"{prefix}: must_be_object")
                continue
            _require_nonempty_string(row, "description", errors, prefix)
            related = _require_string_list(
                row, "related_requirement_ids", errors, prefix
            )
            for ref in related:
                if ref not in req_ids:
                    errors.append(f"{prefix}: unknown_requirement_reference: {ref}")
            if collection == "risks":
                _require_nonempty_string(row, "mitigation", errors, prefix)

    _require_string_list(obj, "missing_information", errors, "step1")
    if errors:
        raise PipelineContractError(errors, stage="step1")
    return obj


def validate_step2(
    data: Any,
    *,
    capability_ids: Set[str],
    requirement_ids: Set[str],
    selection_context: str = "",
    normalize_unsupported_contextual: bool = False,
) -> Dict[str, Any]:
    obj = _require_object(data, "step2")
    errors: List[str] = []
    rows = obj.get("capabilities")
    if not isinstance(rows, list):
        errors.append("step2.capabilities: must_be_array")
        rows = []
    if not rows:
        errors.append("step2.capabilities: empty_capability_selection")
    if len(rows) > 24:
        errors.append("step2.capabilities: maximum_24_items")
    seen: Set[str] = set()
    unsupported_contextual_indices: List[int] = []
    priority_normalizations: List[Dict[str, str]] = []
    for index, row in enumerate(rows):
        prefix = f"step2.capabilities[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{prefix}: must_be_object")
            continue
        cid = str(row.get("capability_id", "") or "").strip().upper()
        row["capability_id"] = cid
        if not re.fullmatch(r"[A-Z]{2}\.[A-Z0-9]{2}", cid):
            errors.append(f"{prefix}: malformed_capability_id: {cid!r}")
        elif cid not in capability_ids:
            errors.append(f"{prefix}: unknown_capability_id: {cid}")
        if cid in seen:
            errors.append(f"{prefix}: duplicate_capability_id: {cid}")
        if cid:
            seen.add(cid)
        priority = str(row.get("priority", "")).strip().upper()
        row["priority"] = priority
        if priority not in PRIORITIES:
            errors.append(f"{prefix}.priority: invalid_enum: {priority}")
        explicit_essential_patterns = {
            "IC.SM": r"\bsimulat\w*\b",
            "IC.PR": r"\b(predict\w*|forecast\w*|remaining useful life|rul)\b",
            "IC.AI": r"\b(automat\w*\s+(?:key\s+)?decision|decision[- ]making)\b",
            "UX.RM": r"\b(real[- ]time|continuous(?:ly)?\s+monitor\w*)\b",
        }
        if (
            normalize_unsupported_contextual
            and selection_context
            and cid in explicit_essential_patterns
            and priority in {"H", "F"}
            and re.search(
                explicit_essential_patterns[cid],
                selection_context,
                flags=re.I,
            )
        ):
            row["priority"] = "E"
            priority_normalizations.append(
                {
                    "action": "raised_priority_for_explicit_requirement",
                    "capability_id": cid,
                    "from_priority": priority,
                    "to_priority": "E",
                    "reason": "capability_is_explicitly_required_by_upstream_context",
                }
            )
        _require_nonempty_string(row, "justification", errors, prefix)
        _require_nonempty_string(row, "deployment_considerations", errors, prefix)
        related = _require_string_list(
            row, "related_requirement_ids", errors, prefix, minimum=1
        )
        for ref in related:
            if ref not in requirement_ids:
                errors.append(f"{prefix}: unknown_requirement_reference: {ref}")
        _require_string_list(row, "assumptions", errors, prefix)
        context = selection_context.casefold()
        contextual_capabilities = {
            "IC.SR": (
                r"\b(search|query|queries|retriev\w*|lookup|look up|find records?)\b",
                "search_or_retrieval_requirement_not_present",
            ),
            "IC.FL": (
                r"\b(federat\w*|multi[- ]site|cross[- ]site|data sovereignty|"
                r"privacy[- ]preserving|cannot centralize|decentrali[sz]\w*)\b",
                "federated_learning_requirement_not_present",
            ),
            "UX.AV": (
                r"\b(advanced visuali[sz]\w*|visual analytics|3d visuali[sz]\w*|"
                r"immersive|spatial interface|augmented reality|virtual reality|xr)\b",
                "advanced_visualization_requirement_not_present",
            ),
        }
        if selection_context and cid in contextual_capabilities:
            pattern, error_code = contextual_capabilities[cid]
            if not re.search(pattern, context, flags=re.I):
                if normalize_unsupported_contextual:
                    unsupported_contextual_indices.append(index)
                else:
                    errors.append(f"{prefix}: {error_code}")
    if normalize_unsupported_contextual and unsupported_contextual_indices:
        removed = [
            {
                "capability_id": str(rows[index].get("capability_id", "")),
                "reason": "explicit_upstream_requirement_not_present",
            }
            for index in unsupported_contextual_indices
            if isinstance(rows[index], dict)
        ]
        obj["capabilities"] = [
            row
            for index, row in enumerate(rows)
            if index not in set(unsupported_contextual_indices)
        ]
        obj.setdefault("selection_normalizations", []).extend(
            {
                "action": "removed_unsupported_contextual_capability",
                **item,
            }
            for item in removed
        )
        if not obj["capabilities"]:
            errors.append(
                "step2.capabilities: empty_after_contextual_grounding"
            )
    if priority_normalizations:
        obj.setdefault("selection_normalizations", []).extend(
            priority_normalizations
        )
    for key in ("capability_gaps", "implementation_phases", "specialized_expertise"):
        _require_string_list(obj, key, errors, "step2")
    if errors:
        raise PipelineContractError(errors, stage="step2")
    return obj


def validate_step3(
    data: Any,
    *,
    capability_ids: Set[str],
    selected_capability_ids: Set[str],
    requirement_ids: Set[str],
    cross_cutting_capability_ids: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    obj = _require_object(data, "step3")
    errors: List[str] = []
    rows = obj.get("deep_dives")
    if not isinstance(rows, list):
        errors.append("step3.deep_dives: must_be_array")
        rows = []
    if not rows:
        errors.append("step3.deep_dives: requires_at_least_1_item")
    if len(rows) > 10:
        errors.append("step3.deep_dives: maximum_10_items")
    allowed_cross_cutting = cross_cutting_capability_ids or set()
    seen: Set[str] = set()
    for index, row in enumerate(rows):
        prefix = f"step3.deep_dives[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{prefix}: must_be_object")
            continue
        cid = str(row.get("capability_id", "") or "").strip().upper()
        row["capability_id"] = cid
        if cid not in capability_ids:
            category = (
                "malformed_capability_id"
                if not re.fullmatch(r"[A-Z]{2}\.[A-Z0-9]{2}", cid)
                else "unknown_capability_id"
            )
            errors.append(f"{prefix}: {category}: {cid}")
        if cid in seen:
            errors.append(f"{prefix}: duplicate_capability_id: {cid}")
        seen.add(cid)
        basis = str(row.get("selection_basis", "")).strip()
        if basis == "selected":
            if cid not in selected_capability_ids:
                errors.append(f"{prefix}: capability_not_selected_in_step2: {cid}")
        elif basis == "cross_cutting_mandatory":
            if cid not in allowed_cross_cutting:
                errors.append(
                    f"{prefix}: capability_not_approved_cross_cutting_mandatory: {cid}"
                )
        else:
            errors.append(f"{prefix}.selection_basis: invalid_enum")
        related = _require_string_list(
            row, "related_requirement_ids", errors, prefix, minimum=1
        )
        for ref in related:
            if ref not in requirement_ids:
                errors.append(f"{prefix}: unknown_requirement_reference: {ref}")
        for key in (
            "specific_requirements",
            "success_criteria",
            "technology_approaches",
            "implementation_challenges",
        ):
            _require_string_list(row, key, errors, prefix, minimum=1)
        _require_string_list(row, "assumptions", errors, prefix)
    if errors:
        raise PipelineContractError(errors, stage="step3")
    return obj


def canonicalize_fourr_result(result: Mapping[str, Any]) -> Dict[str, Any]:
    """Make canonical level codes authoritative for every 4R name."""
    out = deepcopy(dict(result or {}))
    pairs = (
        ("highest_supported_target_level", "highest_supported_target_name"),
        ("recommended_target_level", "recommended_target_name"),
        ("current_supported_target_level", "current_supported_target_name"),
        ("near_term_next_target_level", "near_term_next_target_name"),
        ("feasible_next_target_level", "feasible_next_target_name"),
        ("intended_target_level", "intended_target_name"),
        ("use_case_required_target_level", "use_case_required_target_name"),
        (
            "capability_supported_lower_bound_level",
            "capability_supported_lower_bound_name",
        ),
        (
            "model_evidence_highest_supported_level",
            "model_evidence_highest_supported_name",
        ),
    )
    for code_key, name_key in pairs:
        code = str(out.get(code_key, "") or "").strip().upper()
        if not code:
            out[code_key] = None
            out[name_key] = None
            continue
        if code not in FOURR_LEVEL_NAMES:
            raise PipelineContractError(
                [f"unknown_4r_level: {code_key}={code}"], stage="4r"
            )
        out[code_key] = code
        out[name_key] = FOURR_LEVEL_NAMES[code]
    current_status = str(out.get("current_target_support_status", "")).strip().lower()
    out["current_maturity_confirmed"] = current_status == "supported"
    out["framework_mapping"] = dict(FOURR_LEVEL_NAMES)
    model_planning_summary = str(out.get("planning_summary", "") or "").strip()
    if model_planning_summary:
        out["model_planning_summary"] = model_planning_summary
    current_code = out.get("current_supported_target_level")
    current_name = out.get("current_supported_target_name")
    target_code = out.get("recommended_target_level")
    target_name = out.get("recommended_target_name")
    next_code = out.get("near_term_next_target_level")
    next_name = out.get("near_term_next_target_name")
    endpoint_code = (
        out.get("use_case_required_target_level")
        or out.get("intended_target_level")
        or target_code
    )
    endpoint_name = (
        out.get("use_case_required_target_name")
        or out.get("intended_target_name")
        or target_name
    )
    lower_code = (
        out.get("capability_supported_lower_bound_level")
        or out.get("highest_supported_target_level")
        or current_code
    )
    lower_name = (
        out.get("capability_supported_lower_bound_name")
        or out.get("highest_supported_target_name")
        or current_name
    )
    status_label = current_status or "not confirmed"
    out["planning_summary"] = (
        f"The present evidence baseline is "
        f"{current_code or 'not confirmed'} {current_name or ''} "
        f"({status_label}). The validated near-term build target is "
        f"{target_code or 'not set'} {target_name or ''}. "
        f"The capability-supported lower bound is "
        f"{lower_code or 'not confirmed'} {lower_name or ''}. "
        f"The use-case functional endpoint is "
        f"{endpoint_code or 'not set'} {endpoint_name or ''}."
        + (
            f" The next sequential maturity step is {next_code} {next_name}, after "
            "its listed prerequisites and evidence gaps are resolved."
            if next_code and next_code != target_code
            else ""
        )
    ).strip()
    out["canonical_summary"] = (
        f"Current evidence: "
        f"{current_code or 'not confirmed'} "
        f"{current_name or ''}; "
        f"near-term build target: {target_code or 'not set'} "
        f"{target_name or ''}; supported lower bound: "
        f"{lower_code or 'not confirmed'} {lower_name or ''}; functional endpoint: "
        f"{endpoint_code or 'not set'} {endpoint_name or ''}."
    ).strip()
    return out


def canonicalize_fours_result(
    result: Mapping[str, Any], *, fourr_result: Optional[Mapping[str, Any]] = None
) -> Dict[str, Any]:
    """Enforce canonical 4S naming, row consistency, and 4R compatibility."""
    out = deepcopy(dict(result or {}))
    level = str(out.get("recommended_4s_level", "") or "").strip().upper()
    if level not in FOURS_LEVEL_NAMES:
        level = "S1"
    if fourr_result:
        fourr_level = str(
            fourr_result.get("recommended_target_level", "")
            or fourr_result.get("current_supported_target_level", "")
        ).strip().upper()
        max_level = FOURR_TO_MAX_FOURS.get(fourr_level, "S1")
        # 4S is derived from the validated 4R build boundary. Model prose may
        # explain it, but cannot independently lower or raise the classification.
        level = max_level
        endpoint_fourr_level = str(
            fourr_result.get("use_case_required_target_level", "")
            or fourr_result.get("intended_target_level", "")
            or fourr_level
        ).strip().upper()
        endpoint_level = FOURR_TO_MAX_FOURS.get(
            endpoint_fourr_level, max_level
        )
    else:
        endpoint_level = level
    out["recommended_4s_level"] = level
    out["recommended_4s_name"] = FOURS_LEVEL_NAMES[level]
    out["functional_endpoint_4s_level"] = endpoint_level
    out["functional_endpoint_4s_name"] = FOURS_LEVEL_NAMES[endpoint_level]
    model_reason = str(out.get("reason", "") or "").strip()
    if model_reason:
        out["model_reason"] = model_reason
    next_level = f"S{int(level[1:]) + 1}" if int(level[1:]) < 4 else ""
    out["reason"] = (
        f"The validated near-term simulation requirement is {level} "
        f"{FOURS_LEVEL_NAMES[level]}. The use-case functional simulation endpoint "
        f"is {endpoint_level} {FOURS_LEVEL_NAMES[endpoint_level]}."
        + (
            f" {next_level} {FOURS_LEVEL_NAMES[next_level]} is the next sequential "
            "simulation step once the required model, data, comparison, and "
            "validation evidence exists."
            if next_level
            else ""
        )
    )
    rows_by_level: Dict[str, Dict[str, Any]] = {}
    for raw in out.get("interpretation_table", []) or []:
        if not isinstance(raw, dict):
            continue
        row_level = str(raw.get("level_id", "")).strip().upper()
        if row_level not in FOURS_LEVEL_NAMES:
            continue
        row = deepcopy(raw)
        row["level_id"] = row_level
        row["level_name"] = FOURS_LEVEL_NAMES[row_level]
        row["needed"] = (
            "Yes"
            if int(row_level[1:]) <= int(level[1:])
            else "Target endpoint"
            if int(row_level[1:]) <= int(endpoint_level[1:])
            else "Future"
        )
        rows_by_level[row_level] = row
    out["interpretation_table"] = [
        rows_by_level.get(
            row_level,
            {
                "level_id": row_level,
                "level_name": FOURS_LEVEL_NAMES[row_level],
                "needed": (
                    "Yes"
                    if int(row_level[1:]) <= int(level[1:])
                    else "Target endpoint"
                    if int(row_level[1:]) <= int(endpoint_level[1:])
                    else "Future"
                ),
                "use_case_specific_interpretation": "",
                "required_data_or_model_evidence": "",
                "notes_or_gaps": "",
            },
        )
        for row_level in FOURS_LEVEL_NAMES
    ]
    if level == "S1":
        out["why_s2_is_the_current_target"] = (
            "S2 is a near-term next target, not the current target. It requires "
            "recorded or live comparison cases and evidence that the S1 model is usable."
        )
    if int(endpoint_level[1:]) >= 3 and int(level[1:]) < 3:
        out["why_s3_is_future_work"] = (
            "S3 Predicting is part of the validated functional endpoint, not an "
            "unsupported aspiration. It follows the near-term S1/S2 foundation and "
            "requires validated prediction targets, scenarios, and test data."
        )
    out["framework_mapping"] = dict(FOURS_LEVEL_NAMES)
    out["canonical_summary"] = (
        f"The validated near-term 4S recommendation is {level} "
        f"{FOURS_LEVEL_NAMES[level]}; the functional endpoint is "
        f"{endpoint_level} {FOURS_LEVEL_NAMES[endpoint_level]}."
    )
    return out


def validate_fourr_consistency(result: Mapping[str, Any]) -> Dict[str, Any]:
    """Reject unknown codes and return a canonical 4R object."""
    return canonicalize_fourr_result(result)


def validate_fours_consistency(
    result: Mapping[str, Any], *, fourr_result: Optional[Mapping[str, Any]] = None
) -> Dict[str, Any]:
    """Return a canonical and 4R-compatible 4S object."""
    return canonicalize_fours_result(result, fourr_result=fourr_result)


def validate_dtv_result(
    result: Mapping[str, Any],
    *,
    fourr_result: Optional[Mapping[str, Any]] = None,
    required_traceability_ids: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """Validate placeholders, V&V row fields, target ownership, and coverage."""
    out = deepcopy(dict(result or {}))
    errors: List[str] = []
    if contains_placeholder(out):
        errors.append("placeholder_detected")
    if fourr_result:
        expected = str(
            fourr_result.get("recommended_target_level", "")
            or fourr_result.get("current_supported_target_level", "")
        ).strip().upper()
        actual = str(out.get("target_4r_level", expected) or "").strip().upper()
        if actual and expected and actual != expected:
            errors.append(
                f"dtv_cannot_override_4r_target: expected={expected}, actual={actual}"
            )
        out["target_4r_level"] = expected
        out["target_4r_name"] = FOURR_LEVEL_NAMES.get(expected, "")
        endpoint = str(
            fourr_result.get("use_case_required_target_level", "")
            or fourr_result.get("intended_target_level", "")
            or expected
        ).strip().upper()
        out["functional_endpoint_4r_level"] = endpoint
        out["functional_endpoint_4r_name"] = FOURR_LEVEL_NAMES.get(endpoint, "")

    rows = out.get("validation_items", out.get("dtv_development_and_vv_table", []))
    if not isinstance(rows, list):
        errors.append("validation_items: must_be_array")
        rows = []
    required_fields = (
        "claim_being_validated",
        "evidence_required",
        "test_method",
        "acceptance_criterion",
        "responsible_role",
        "lifecycle_phase",
        "related_requirement_or_kpi",
    )
    seen_ids: Set[str] = set()
    covered: Set[str] = set()
    for index, row in enumerate(rows):
        prefix = f"validation_items[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{prefix}: must_be_object")
            continue
        validation_id = str(
            row.get("validation_item_id", f"VNV-{index + 1:03d}")
        ).strip()
        row["validation_item_id"] = validation_id
        if not _ID_PATTERNS["validation"].fullmatch(validation_id):
            errors.append(f"{prefix}: malformed_validation_item_id")
        if validation_id in seen_ids:
            errors.append(f"{prefix}: duplicate_validation_item_id")
        seen_ids.add(validation_id)
        for key in required_fields:
            value = str(row.get(key, "") or "").strip()
            if not value:
                errors.append(f"{prefix}.{key}: missing_or_empty")
            elif contains_placeholder(value):
                errors.append(f"{prefix}.{key}: placeholder_detected")
        ref = str(row.get("related_requirement_or_kpi", "") or "").strip()
        if ref:
            covered.add(ref)
        if required_traceability_ids and ref not in required_traceability_ids:
            errors.append(f"{prefix}: unknown_traceability_reference: {ref}")
    required = set(required_traceability_ids or set())
    missing = sorted(required - covered)
    out["validation_items"] = rows
    out["validation_coverage"] = {
        "required_ids": sorted(required),
        "covered_ids": sorted(covered & required if required else covered),
        "missing_ids": missing,
        "complete": not missing,
    }
    if errors:
        raise PipelineContractError(errors, stage="dtv")
    return out


def semantic_dedupe(
    rows: Sequence[Mapping[str, Any]],
    *,
    text_keys: Sequence[str],
    threshold: float = 0.78,
) -> List[Dict[str, Any]]:
    """Remove semantically repetitive rows using deterministic token overlap."""
    kept: List[Dict[str, Any]] = []
    signatures: List[Set[str]] = []
    for row in rows:
        text = " ".join(str(row.get(key, "")) for key in text_keys)
        tokens = {
            token
            for token in re.findall(r"[a-z0-9]+", text.casefold())
            if len(token) > 2
        }
        duplicate = False
        for prior in signatures:
            union = tokens | prior
            similarity = (len(tokens & prior) / len(union)) if union else 1.0
            if similarity >= threshold:
                duplicate = True
                break
        if not duplicate:
            kept.append(deepcopy(dict(row)))
            signatures.append(tokens)
    return kept


def _dedupe(items: Sequence[str]) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for item in items:
        if item not in seen:
            out.append(item)
            seen.add(item)
    return out
