"""Traceability, prerequisite scoring, and DTV enrichment."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Set

from .contracts import (
    FOURR_LEVEL_NAMES,
    PREREQUISITE_STATES,
    PipelineContractError,
    semantic_dedupe,
    validate_dtv_result,
)


PREREQUISITE_WEIGHTS: Dict[str, float] = {
    "confirmed_available": 1.0,
    "partially_available": 0.5,
    "unknown": 0.2,
    "missing": 0.0,
    "not_applicable": 1.0,
}


def score_prerequisites(
    capability: Mapping[str, Any],
    states: Sequence[str],
) -> Dict[str, Any]:
    """Score readiness without treating unknown prerequisites as available.

    A capability is feasible now only when every hard gate is either confirmed
    available or not applicable. Unknown hard gates make feasibility unknown.
    """
    prerequisites = list(capability.get("prerequisites", []))
    if len(states) != len(prerequisites):
        raise PipelineContractError(
            [
                "prerequisite_state_count_mismatch: "
                f"{len(states)} states for {len(prerequisites)} prerequisites"
            ],
            stage="feasibility",
        )
    invalid = [state for state in states if state not in PREREQUISITE_STATES]
    if invalid:
        raise PipelineContractError(
            [f"invalid_prerequisite_state: {state}" for state in invalid],
            stage="feasibility",
        )
    hard = {
        int(index)
        for index in capability.get("hard_gates", [])
        if isinstance(index, int) or str(index).isdigit()
    }
    hard_states = [states[index] for index in sorted(hard) if index < len(states)]
    if any(state == "missing" for state in hard_states):
        feasibility_state = "missing_prerequisite"
    elif any(state in {"unknown", "partially_available"} for state in hard_states):
        feasibility_state = "not_confirmed"
    else:
        feasibility_state = "confirmed_feasible"
    readiness = (
        sum(PREREQUISITE_WEIGHTS[state] for state in states) / len(states)
        if states
        else 0.0
    )
    confidence = (
        sum(
            1.0
            if state in {"confirmed_available", "missing", "not_applicable"}
            else 0.5
            if state == "partially_available"
            else 0.0
            for state in states
        )
        / len(states)
        if states
        else 0.0
    )
    return {
        "cap_id": capability.get("cap_id", ""),
        "cap_name": capability.get("cap_name", ""),
        "priority": capability.get("priority", ""),
        "feasible_now": feasibility_state == "confirmed_feasible",
        "feasibility_state": feasibility_state,
        "readiness_score": round(readiness, 3),
        "readiness_confidence": round(confidence, 3),
        "prerequisite_states": list(states),
        "unknown_indices": [
            index for index, state in enumerate(states) if state == "unknown"
        ],
        "missing_indices": [
            index for index, state in enumerate(states) if state == "missing"
        ],
        "missing_hard_gate_indices": [
            index
            for index in sorted(hard)
            if index < len(states)
            and states[index] not in {"confirmed_available", "not_applicable"}
        ],
        "scoring_method": (
            "confirmed=1.0, partial=0.5, unknown=0.2, missing=0.0, "
            "not_applicable=1.0; all hard gates must be confirmed or not applicable"
        ),
    }


def build_traceability(
    *,
    step1: Mapping[str, Any],
    step2: Mapping[str, Any],
    step3: Mapping[str, Any],
) -> Dict[str, Any]:
    requirement_to_capabilities: Dict[str, List[str]] = {
        row["requirement_id"]: [] for row in step1.get("requirements", [])
    }
    capability_to_requirements: Dict[str, List[str]] = {}
    for capability in step2.get("capabilities", []):
        cid = capability.get("capability_id", "")
        refs = list(capability.get("related_requirement_ids", []))
        capability_to_requirements[cid] = refs
        for ref in refs:
            requirement_to_capabilities.setdefault(ref, []).append(cid)
    deep_dive_by_capability = {
        row.get("capability_id", ""): True for row in step3.get("deep_dives", [])
    }
    rows: List[Dict[str, Any]] = []
    for requirement in step1.get("requirements", []):
        req_id = requirement.get("requirement_id", "")
        capabilities = requirement_to_capabilities.get(req_id, [])
        rows.append(
            {
                "input_id": "INPUT-001",
                "requirement_id": req_id,
                "objective_ids": [
                    row.get("objective_id")
                    for row in step1.get("objectives", [])
                    if req_id in row.get("related_requirement_ids", [])
                ],
                "kpi_ids": [
                    kpi.get("kpi_id")
                    for kpi in step1.get("kpis", [])
                    if any(
                        objective_id in kpi.get("related_objective_ids", [])
                        for objective_id in [
                            objective.get("objective_id")
                            for objective in step1.get("objectives", [])
                            if req_id in objective.get("related_requirement_ids", [])
                        ]
                    )
                ],
                "capability_ids": capabilities,
                "deep_dive_capability_ids": [
                    cid for cid in capabilities if deep_dive_by_capability.get(cid)
                ],
            }
        )
    return {
        "input": {"input_id": "INPUT-001", "source": "user_problem_statement"},
        "rows": rows,
        "capability_to_requirement_ids": capability_to_requirements,
        "unmapped_requirement_ids": sorted(
            req_id
            for req_id, capabilities in requirement_to_capabilities.items()
            if not capabilities
        ),
    }


def enrich_dtv_result(
    result: Mapping[str, Any],
    *,
    step1: Mapping[str, Any],
    fourr_result: Mapping[str, Any],
) -> Dict[str, Any]:
    """Build complete, traceable V&V items without letting DTV redefine 4R."""
    out = deepcopy(dict(result or {}))
    target = str(
        fourr_result.get("recommended_target_level", "")
        or fourr_result.get("current_supported_target_level", "")
    ).strip().upper()
    out["target_4r_level"] = target
    out["target_4r_name"] = FOURR_LEVEL_NAMES.get(target, "")

    required_refs = [
        row.get("kpi_id", "") for row in step1.get("kpis", []) if row.get("kpi_id")
    ]
    required_refs.extend(
        row.get("objective_id", "")
        for row in step1.get("objectives", [])
        if row.get("objective_id")
    )
    source_rows = [
        row
        for row in out.get("dtv_development_and_vv_table", [])
        if isinstance(row, dict)
    ]
    validation_items: List[Dict[str, Any]] = []
    for index, row in enumerate(source_rows):
        related = (
            required_refs[index % len(required_refs)]
            if required_refs
            else "unknown_requires_confirmation"
        )
        action = str(row.get("existing_4r_action_item", "") or "").strip()
        validate_text = str(
            row.get("what_should_be_validated")
            or row.get("what_should_be_verified")
            or action
            or ""
        ).strip()
        claim = f"{action}: {validate_text}" if action else validate_text
        verify_text = str(row.get("what_should_be_verified", "") or "").strip()
        verify_text = verify_text.removeprefix("Verify ").removeprefix("verify ")
        validate_method = str(
            row.get("what_should_be_validated", "") or ""
        ).strip()
        validate_method = validate_method.removeprefix("Validate ").removeprefix(
            "validate "
        )
        validation_items.append(
            {
                "validation_item_id": f"VNV-{index + 1:03d}",
                "claim_being_validated": claim,
                "evidence_required": row.get("evidence_to_collect", ""),
                "test_method": "Verify "
                + verify_text
                + "; validate "
                + validate_method,
                "acceptance_criterion": row.get(
                    "suggested_acceptance_criteria", ""
                ),
                "responsible_role": "unknown_requires_confirmation",
                "lifecycle_phase": row.get("dtv_stage_or_focus_area")
                or "integration_and_testing",
                "related_requirement_or_kpi": related,
                "related_4r_action_item": row.get("existing_4r_action_item", ""),
            }
        )
    validation_items = semantic_dedupe(
        validation_items,
        text_keys=("claim_being_validated", "test_method", "acceptance_criterion"),
    )
    for index, row in enumerate(validation_items, start=1):
        row["validation_item_id"] = f"VNV-{index:03d}"
    covered = {
        row.get("related_requirement_or_kpi", "") for row in validation_items
    }
    lookup = {
        **{
            row.get("kpi_id", ""): row.get("name", "")
            for row in step1.get("kpis", [])
        },
        **{
            row.get("objective_id", ""): row.get("description", "")
            for row in step1.get("objectives", [])
        },
    }
    for ref in required_refs:
        if ref in covered:
            continue
        index = len(validation_items) + 1
        label = str(lookup.get(ref, ref)).strip()
        validation_items.append(
            {
                "validation_item_id": f"VNV-{index:03d}",
                "claim_being_validated": f"The digital twin supports {label}",
                "evidence_required": (
                    f"Traceable test results and stakeholder review evidence for {ref}"
                ),
                "test_method": (
                    f"Execute a representative use-case test and compare its result "
                    f"with the approved definition of {ref}"
                ),
                "acceptance_criterion": (
                    f"The owner of {ref} confirms the documented result satisfies "
                    "the approved measurement or objective."
                ),
                "responsible_role": "unknown_requires_confirmation",
                "lifecycle_phase": "integration_and_testing",
                "related_requirement_or_kpi": ref,
                "related_4r_action_item": "",
            }
        )
    out["validation_items"] = validation_items
    return validate_dtv_result(
        out,
        fourr_result=fourr_result,
        required_traceability_ids=set(required_refs),
    )
