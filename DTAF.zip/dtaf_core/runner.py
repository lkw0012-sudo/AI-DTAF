"""Reusable generation, validation, repair, and strict-retry orchestration."""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence

from .contracts import PipelineContractError, STAGE_STATUSES, parse_json_response


@dataclass
class ModelCallResult:
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class StageAttempt:
    attempt: int
    kind: str
    duration_seconds: float
    output_characters: int
    valid: bool
    validation_errors: List[str]
    model_metadata: Dict[str, Any]
    raw_response_file: str


@dataclass
class StageRunResult:
    stage: str
    status: str
    data: Optional[Dict[str, Any]]
    attempts: List[StageAttempt]
    failure_classification: str = ""
    validation_errors: List[str] = field(default_factory=list)

    @property
    def priority_source(self) -> str:
        return "model" if self.status == "successful" else "model_repair"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "stage": self.stage,
            "status": self.status,
            "data_present": self.data is not None,
            "failure_classification": self.failure_classification,
            "validation_errors": list(self.validation_errors),
            "attempts": [asdict(attempt) for attempt in self.attempts],
        }


ModelCallable = Callable[
    [str, Sequence[Mapping[str, str]], Dict[str, Any]],
    Any,
]
ValidatorCallable = Callable[[Any], Dict[str, Any]]
EventCallable = Callable[[Dict[str, Any]], None]


class ValidatedStageRunner:
    """Execute at most initial + repair + strict attempts for one stage."""

    def __init__(
        self,
        *,
        raw_dir: Path,
        max_validation_retries: int = 2,
        on_event: Optional[EventCallable] = None,
    ) -> None:
        self.raw_dir = Path(raw_dir)
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.max_validation_retries = max(0, min(int(max_validation_retries), 2))
        self.on_event = on_event

    def run(
        self,
        *,
        stage: str,
        base_messages: Sequence[Mapping[str, str]],
        schema: Dict[str, Any],
        validator: ValidatorCallable,
        call_model: ModelCallable,
        prompt_template_version: str,
    ) -> StageRunResult:
        attempts: List[StageAttempt] = []
        invalid_text = ""
        invalid_errors: List[str] = []
        total_attempts = 1 + self.max_validation_retries

        for attempt_number in range(1, total_attempts + 1):
            kind = self._attempt_kind(attempt_number)
            messages = self._messages_for_attempt(
                kind=kind,
                base_messages=base_messages,
                schema=schema,
                invalid_text=invalid_text,
                validation_errors=invalid_errors,
            )
            started = time.monotonic()
            call_error = ""
            try:
                raw_result = call_model(kind, messages, schema)
            except Exception as exc:
                call_error = f"{type(exc).__name__}: {exc}"
                raw_result = ModelCallResult(
                    "",
                    {
                        "call_error": call_error,
                        "stop_reason": "call_error",
                    },
                )
            duration = time.monotonic() - started
            model_result = self._coerce_model_result(raw_result)
            raw_file = self.raw_dir / f"raw_{stage}_{attempt_number}_{kind}.txt"
            raw_file.write_text(model_result.content, encoding="utf-8")
            errors: List[str] = []
            parsed: Any = None
            validated: Optional[Dict[str, Any]] = None
            try:
                parsed = parse_json_response(model_result.content)
                validated = validator(parsed)
            except PipelineContractError as exc:
                errors = list(exc.errors)
            except Exception as exc:
                errors = [f"validation_exception: {type(exc).__name__}: {exc}"]
            if call_error:
                errors.insert(0, f"model_call_error: {call_error}")
            stop_reason = str(
                model_result.metadata.get("stop_reason")
                or model_result.metadata.get("finish_reason")
                or ""
            ).strip().lower()
            if validated is None and stop_reason in {
                "length",
                "max_tokens",
                "token_limit",
            }:
                errors.insert(0, "generation_stopped_at_token_limit")

            attempt = StageAttempt(
                attempt=attempt_number,
                kind=kind,
                duration_seconds=round(duration, 6),
                output_characters=len(model_result.content),
                valid=validated is not None,
                validation_errors=errors,
                model_metadata={
                    **dict(model_result.metadata),
                    "prompt_template_version": prompt_template_version,
                },
                raw_response_file=raw_file.name,
            )
            attempts.append(attempt)
            self._emit(
                {
                    "event": "stage_attempt",
                    "stage": stage,
                    **asdict(attempt),
                }
            )
            if validated is not None:
                status = "successful" if attempt_number == 1 else "repaired"
                result = StageRunResult(
                    stage=stage,
                    status=status,
                    data=validated,
                    attempts=attempts,
                )
                self._write_attempt_manifest(stage, result)
                return result
            invalid_text = model_result.content
            invalid_errors = errors

        result = StageRunResult(
            stage=stage,
            status="failed",
            data=None,
            attempts=attempts,
            failure_classification=self._classify_failure(invalid_errors),
            validation_errors=invalid_errors,
        )
        self._write_attempt_manifest(stage, result)
        self._emit(
            {
                "event": "stage_failed",
                "stage": stage,
                "status": result.status,
                "failure_classification": result.failure_classification,
                "validation_errors": result.validation_errors,
                "attempt_count": len(attempts),
            }
        )
        return result

    @staticmethod
    def _attempt_kind(attempt_number: int) -> str:
        if attempt_number == 1:
            return "initial"
        if attempt_number == 2:
            return "repair"
        return "strict"

    @staticmethod
    def _coerce_model_result(value: Any) -> ModelCallResult:
        if isinstance(value, ModelCallResult):
            return value
        if isinstance(value, tuple) and len(value) == 2:
            return ModelCallResult(str(value[0] or ""), dict(value[1] or {}))
        if isinstance(value, dict) and "content" in value:
            return ModelCallResult(
                str(value.get("content") or ""),
                dict(value.get("metadata") or {}),
            )
        return ModelCallResult(str(value or ""), {})

    @staticmethod
    def _messages_for_attempt(
        *,
        kind: str,
        base_messages: Sequence[Mapping[str, str]],
        schema: Dict[str, Any],
        invalid_text: str,
        validation_errors: Sequence[str],
    ) -> List[Dict[str, str]]:
        base = [
            {"role": str(item["role"]), "content": str(item["content"])}
            for item in base_messages
        ]
        if kind == "initial":
            return base
        if kind == "repair":
            joined_errors = " ".join(validation_errors).casefold()
            if (
                "truncated_json" in joined_errors
                or "token_limit" in joined_errors
            ):
                return [
                    {
                        "role": "system",
                        "content": (
                            "Regenerate a shorter complete DTAF JSON object. The prior "
                            "response hit the token limit and cannot be repaired safely. "
                            "Return ONLY JSON matching the schema. Consolidate related "
                            "items, obey every maxItems constraint, and preserve only "
                            "facts supported by the original context."
                        ),
                    },
                    *base,
                    {
                        "role": "user",
                        "content": (
                            "The prior response was truncated. Generate a new concise "
                            "object from the original context using this schema:\n"
                            f"{json.dumps(schema, indent=2)}\n\n"
                            f"Errors to avoid:\n"
                            f"{json.dumps(list(validation_errors), indent=2)}"
                        ),
                    },
                ]
            return [
                {
                    "role": "system",
                    "content": (
                        "Repair the invalid DTAF stage response. Return ONLY a complete "
                        "JSON object matching the schema. Preserve supported content, fix "
                        "every listed validation error, and do not add unsupported facts."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Required schema:\n{json.dumps(schema, indent=2)}\n\n"
                        f"Validation errors:\n{json.dumps(list(validation_errors), indent=2)}\n\n"
                        f"Invalid response:\n{invalid_text[:30000]}"
                    ),
                },
            ]
        return [
            {
                "role": "system",
                "content": (
                    "Generate the DTAF stage again from scratch. Return ONLY one complete "
                    "JSON object matching the schema. No Markdown, prose wrapper, code fence, "
                    "placeholder, unknown identifier, or unsupported current-state claim."
                ),
            },
            *base,
            {
                "role": "user",
                "content": (
                    "The prior attempts failed validation. Follow this schema exactly:\n"
                    f"{json.dumps(schema, indent=2)}\n\n"
                    f"Errors to avoid:\n{json.dumps(list(validation_errors), indent=2)}"
                ),
            },
        ]

    @staticmethod
    def _classify_failure(errors: Sequence[str]) -> str:
        joined = " ".join(errors).casefold()
        if "empty_capability_selection" in joined:
            return "empty_selection"
        if "unknown_capability" in joined or "malformed_capability" in joined:
            return "invalid_identifier"
        if "truncated" in joined or "unclosed" in joined or "token_limit" in joined:
            return "incomplete_response"
        if "malformed_json" in joined:
            return "malformed_json"
        if "placeholder" in joined:
            return "placeholder_content"
        if "reference" in joined:
            return "traceability_failure"
        return "schema_validation_failure"

    def _write_attempt_manifest(self, stage: str, result: StageRunResult) -> None:
        path = self.raw_dir / f"{stage}_attempts.json"
        path.write_text(json.dumps(result.to_dict(), indent=2), encoding="utf-8")

    def _emit(self, event: Dict[str, Any]) -> None:
        if self.on_event is not None:
            self.on_event(event)


def validate_pipeline_status_records(records: Sequence[Mapping[str, Any]]) -> None:
    """Raise if a pipeline status record uses an unsupported state."""
    errors = []
    for index, record in enumerate(records):
        status = str(record.get("status", "")).strip()
        if status not in STAGE_STATUSES:
            errors.append(f"pipeline_status[{index}]: invalid_status: {status}")
    if errors:
        raise PipelineContractError(errors, stage="pipeline_status")
